# Backlog — Campus Services Pilot

## Items

1. **StudyMatch: college-scoped first-year matching** — Must. First-year students may only match with students from their own college. Acceptance: an eligible same-college match is allowed; a cross-college match is rejected and explained.
2. **CampusEats: offline-safe ordering** — Must. The ordering flow remains usable when food-court Wi-Fi drops. Acceptance: an order is queued with a visible pending state and is submitted once connectivity returns without duplication.
3. **LabLoans: weekly open-loan report** — Must. Produce every open loan once per week, including borrower, equipment, due date, and status. Acceptance: the report includes every open loan and identifies overdue items.
4. Shared sign-in and role permissions — Must. Only authorised users can perform actions for their role.
5. Audit and retry visibility — Should. Record important decisions and show whether an operation is pending, complete, or failed.

## The change

The sealed requests add three constraints: CampusEats must tolerate lunchtime Wi-Fi outages; StudyMatch must enforce the first-year same-college boundary; and LabLoans must provide a weekly report of every open loan before exams.

## From the assistant

Kept:

- All three requests are accepted because each addresses a concrete operational, policy, or risk need.
- The StudyMatch college rule is a non-negotiable Must and is implemented as an eligibility boundary.
- CampusEats offline behaviour and LabLoans reporting are sprint priorities because their deadlines and failure costs are high.

Rejected:

- No request was rejected. Lower-priority polish and unrelated features remain outside Sprint 1 so the team can deliver the safety and policy constraints first.

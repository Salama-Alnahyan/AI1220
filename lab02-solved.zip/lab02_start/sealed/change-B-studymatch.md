<!-- SEALED — incorporated into the completed Lab 02 planning record. -->

From: student council president
Subject: FW: Dean's office

The Dean's office called about the matching idea: for their first semester, first-years may only be matched with students from their own college. Non-negotiable, effective immediately.

Decision: Accepted as BACKLOG item 1 and a non-negotiable Sprint 1 policy rule. Cross-college first-year matches are rejected.

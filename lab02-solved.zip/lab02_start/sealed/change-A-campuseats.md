<!-- SEALED — incorporated into the completed Lab 02 planning record. -->

From: food-services manager
Subject: one more thing

Forgot to mention — the food-court Wi-Fi drops most lunchtimes, right when it's busiest. Whatever you build has to keep working when that happens.

Decision: Accepted as BACKLOG item 2 and Sprint 1 scope. The ordering flow queues requests locally, exposes pending state, retries after reconnection, and prevents duplicate submission.

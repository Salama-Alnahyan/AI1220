<!-- SEALED — incorporated into the completed Lab 02 planning record. -->

From: lab technician
Subject: audit results

The audit came back: most equipment goes missing during exam weeks. I now need a weekly report of every open loan — and exams start soon.

Decision: Accepted as BACKLOG item 3 and Sprint 1 scope. The report lists every open loan and flags overdue items.

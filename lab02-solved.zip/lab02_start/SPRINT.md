# Sprint 1 — Campus Services Pilot

## Sprint Goal

Deliver the highest-risk policy and operational safeguards for the pilot: enforce the first-year same-college matching rule, make CampusEats resilient to Wi-Fi interruptions, and produce a reliable weekly open-loan report.

## Selected items

- StudyMatch same-college eligibility rule.
- CampusEats queued ordering with retry and duplicate protection.
- LabLoans weekly open-loan report.
- Role checks and audit entries for the three flows.

## Definition of Done

- Each selected item has an observable acceptance test and a documented failure path.
- A first-year cross-college match is rejected; a same-college match succeeds.
- An order submitted during a simulated Wi-Fi outage is retained, visibly pending, and synchronised once without duplication.
- The weekly LabLoans report includes every open loan, overdue status, and report timestamp.
- Unauthorised roles are denied, and important decisions or retries are auditable.
- Tests pass, a stakeholder reviews the demo, and known limitations are recorded before release.

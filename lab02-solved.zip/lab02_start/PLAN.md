# Plan — Campus Services Pilot

## Process choice

### How stable and binding are the requirements?

The initial requirements are useful but subject to policy and operational changes, so they are not fully stable or binding yet.

### How quickly can real feedback arrive?

Feedback can arrive during the pilot and from operational staff each week. A short, reviewable cycle is appropriate.

### What does failure cost?

Failure could exclude students, lose loan equipment, or make the service unusable during a network outage. Safety, privacy, and policy constraints must be tested before release.

### How many pieces must move together?

The three capabilities can be delivered independently, but shared identity, data, and reporting rules must be coordinated.

Verdict: Use a lightweight iterative process with a prioritised backlog, a one-week sprint, explicit acceptance criteria, and a change review before work is committed. Treat policy constraints as Must items.

## Milestones

| Milestone | When | What is true then |
|---|---|---|
| Baseline and scope | Day 1 | Core user flows, constraints, and out-of-scope items are recorded. |
| Sprint 1 implementation | Days 2–6 | Highest-priority flow works with tests and a reviewable demo. |
| Change review | Day 7 | Wi-Fi resilience, college matching, and weekly open-loan reporting are accepted into scope with acceptance criteria. |
| Pilot readiness | Day 10 | Security, offline/retry behaviour, policy rules, and report accuracy are verified. |

## Risks

| Risk | Likelihood | Mitigation |
|---|---|---|
| Food-court Wi-Fi drops during peak demand | High | Queue writes locally, show sync state, retry safely, and test with network loss. |
| Matching violates the Dean's first-year college rule | Medium | Enforce the college boundary in eligibility logic and add a negative test. |
| Open-loan data is incomplete during exam weeks | Medium | Generate a scheduled weekly report from authoritative loan records and reconcile exceptions. |
| Privacy or permission errors expose student or loan data | Medium | Use least-privilege roles, audit changes, and test unauthorized access. |

# CampusPulse requirements review

Name or team: Salama-Alnahyan

Reviewer: Salama-Alnahyan

Date: 2026-09-28

Review the completed `stakeholders.md` and `REQUIREMENTS.md`. Refer to specific IDs and evidence in every answer.

## Validity

The requirements reflect the evidence. UR-1 and UR-2 address S1's need for one accessible service and private RSVP. UR-3 and UR-4 address S2's approval and correction-notification needs. UR-5 reflects S3's report, hide, evidence, and accountability needs. UR-6 uses S4's verified-group and 5,000-student/200-group pilot boundary. UR-7 addresses S5's minimisation, private-by-default, and 30-day deletion rule. S6 is represented by the permission, moderation, and abuse controls in FR-3, FR-5, and the US-3 non-moderator criterion.

## Consistency

The scope and MoSCoW list agree: the listed Won't items are not included in release scope, while followed events, announcements, RSVP, visibility, moderation, appeals, verification, and privacy are in scope. UR-2's private RSVP default is consistent with NFR-3, and FR-8/NFR-4 consistently apply S5's 30-day deletion rule. The only unresolved tension is the public audience versus private RSVP identity; the chosen design exposes event visibility without exposing attendee names unless the student opts in, consistent with S1 and S5.

## Completeness

The document covers normal flows through FR-1, FR-3, FR-4, and FR-7; failure and permission boundaries through US-2 and US-3; privacy through FR-2, FR-8, NFR-3, and NFR-4; moderation and appeals through FR-5; accessibility through NFR-2; and the abuse threat from S6 through approval, verification, audit, and non-moderator denial. A peak-concurrency figure is missing from the brief, so Q1 records it as an open question rather than inventing a stakeholder target.

## Realism

The browser-based scope is realistic for a first release because native apps and unrelated features are explicitly excluded. NFR-1 uses the supplied 5,000-student/200-group pilot target, while NFR-2, NFR-3, and NFR-4 are testable release and audit conditions. Exact Orientation Week concurrency and notification latency are not supplied, so Q1 must be answered before final performance commitments. The deletion and audit requirements are feasible if the service has scheduled jobs and immutable audit storage.

## Verifiability

Every FR names an observable behaviour and traces to an existing UR. NFR-1 states a population and pass condition; NFR-2 has a defined accessibility-check target; NFR-3 states zero unauthorised disclosures; NFR-4 states a 30-day deadline and audit sample; and NFR-5 states the required audit fields. Remaining ambiguity is limited to the agreed accessibility test suite and the definition of peak concurrency; these are explicit follow-up items rather than hidden assumptions.

## One requirement you revised

- Requirement ID: NFR-1
- Before: `The system shall support the pilot scale.`
- What was wrong or missing: It did not state what scale meant, what would be measured, or when the target applied, so a tester could not decide pass or fail.
- After: `The system shall support 5,000 student accounts and 200 groups while preserving the FR-1 through FR-7 behaviours during pilot readiness testing. [Measure: 100% of defined pilot scenarios pass at the stated population; condition: before Orientation Week] [Source: UR-6]`
- Evidence or stakeholder to confirm the change: S4 explicitly states 5,000 students and 200 groups before Orientation Week; Student Affairs should confirm the scenario set and peak-concurrency question Q1.

## Final check

- [x] Stakeholder conflicts have a decision or a follow-up question.
- [x] Scope exclusions agree with the Won't list.
- [x] Every FR and NFR traces to a user requirement.
- [x] Every NFR contains a measurable target and condition.
- [x] Traceability rows use IDs that exist in the document.
- [x] The revised requirement has also been updated in the traceability table.

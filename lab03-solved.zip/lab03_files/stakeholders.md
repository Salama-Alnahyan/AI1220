# CampusPulse stakeholder analysis

Name or team: Salama-Alnahyan

Date: 2026-09-28

## S1

- Stakeholder: Student attendee
- Stakeholder type: end user
- Power-interest quadrant: keep informed
- Main goal: Find followed-club events and RSVP from a phone.
- Main concern: RSVP privacy, accessibility, and having to check many channels.
- How you would involve or monitor this stakeholder: Usability tests with mobile users and screen-reader users; monitor RSVP privacy complaints and task completion.

## S2

- Stakeholder: Group officer
- Stakeholder type: end user
- Power-interest quadrant: key player
- Main goal: Draft, collaborate on, and publish accurate announcements for the right audience.
- Main concern: Only approved officers can publish and changes must reach RSVP holders.
- How you would involve or monitor this stakeholder: Review publishing workflows, permission tests, and correction-notification feedback.

## S3

- Stakeholder: Campus moderator
- Stakeholder type: operations
- Power-interest quadrant: key player
- Main goal: Review reports, hide harmful events quickly, and preserve appeal evidence.
- Main concern: Decisions need an accountable audit trail without destroying evidence.
- How you would involve or monitor this stakeholder: Scenario reviews, moderation response-time metrics, and audit-log sampling.

## S4

- Stakeholder: Student Affairs
- Stakeholder type: business
- Power-interest quadrant: key player
- Main goal: Run a credible pilot for 5,000 students and 200 groups before Orientation Week.
- Main concern: Official verification must be meaningful and the release must scale to the pilot.
- How you would involve or monitor this stakeholder: Approve scope and verification policy; review readiness metrics and pilot feedback.

## S5

- Stakeholder: Data Protection Officer
- Stakeholder type: regulator
- Power-interest quadrant: keep satisfied
- Main goal: Ensure collection and retention of personal data are necessary and controlled.
- Main concern: RSVP lists must be private by default and cancelled-event attendance data deleted within 30 days.
- How you would involve or monitor this stakeholder: Privacy review, retention checks, access-log review, and deletion evidence.

## S6

- Stakeholder: Abuse cases and malicious actors
- Stakeholder type: negative stakeholder
- Power-interest quadrant: minimal effort
- Main goal: Impersonate verified groups, publish phishing events, or repeat announcements.
- Main concern: Abuse can harm students and undermine trust.
- How you would involve or monitor this stakeholder: Do not involve directly; use threat modelling, abuse reports, rate limits, verification controls, and incident monitoring.

## Conflicts to resolve

### Conflict 1

- Stakeholders: S1 and S4
- What conflicts: Students want private RSVP information, while Student Affairs wants a visible, trusted campus event service.
- Proposed decision or follow-up question: Keep RSVP lists private by default and expose only aggregate attendance unless the student explicitly opts in. Confirm with Student Affairs whether any event category requires a different policy.

### Conflict 2

- Stakeholders: S2 and S3
- What conflicts: Officers want fast publication and correction, while moderators need approval, evidence preservation, and the ability to hide an event immediately.
- Proposed decision or follow-up question: Allow drafts and corrections by officers, but require approved-officer publication and preserve immutable moderation evidence when content is hidden. Ask whether emergency moderator hiding needs a notification SLA.

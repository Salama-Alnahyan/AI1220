# CampusPulse requirements

Name or team: Salama-Alnahyan

Date: 2026-09-28

Status: validated working draft

## 1. Release scope

### In scope

- University sign-in, verified groups, and official badges.
- Following, announcements, events, audience visibility, corrections, and RSVP.
- Reports, moderation, appeals, privacy controls, accessibility, and retention rules.

### Out of scope

- Direct messages, external users, payments, video hosting, and AI recommendations.
- Native mobile applications; the first release is browser-based.

## 2. User requirements

- UR-1 [Must] As a student, I can find announcements and events from groups I follow in one browser service, including on a phone. [Source: S1]
- UR-2 [Must] As a student, I can RSVP while keeping my name off public lists unless I explicitly choose visibility. [Source: S1, S5]
- UR-3 [Must] As a group officer, I can collaborate on an announcement but only an approved officer can publish it to the selected audience. [Source: S2]
- UR-4 [Must] As a group officer, I can correct event place or time and notify students who RSVP'd. [Source: S2]
- UR-5 [Must] As a moderator, I can review reports, hide harmful events, and preserve evidence and decision ownership for appeals. [Source: S3]
- UR-6 [Must] As Student Affairs, I can identify verified groups and operate the pilot for 5,000 students and 200 groups before Orientation Week. [Source: S4]
- UR-7 [Must] As the Data Protection Officer, I can verify that personal data is minimised, RSVP visibility starts private, and cancelled-event attendance data is deleted within 30 days. [Source: S5]

## 3. Functional requirements

- FR-1 [Must] The system shall authenticate users with university sign-in and allow a student to follow a verified group and view its announcements and events. [Source: UR-1]
- FR-2 [Must] The system shall create an RSVP with private attendee visibility by default and record a student's explicit choice before displaying their name publicly. [Source: UR-2]
- FR-3 [Must] The system shall allow an authorised officer to create a draft and shall allow publication only when the officer has approved publishing permission for that group and audience. [Source: UR-3]
- FR-4 [Must] The system shall record event place or time corrections and notify every student with an RSVP for the affected event. [Source: UR-4]
- FR-5 [Must] The system shall record a report's content and reason, allow a moderator to hide an event, and retain the report, evidence, and decision-maker identity for an appeal. [Source: UR-5]
- FR-6 [Must] The system shall display an official badge only for a group whose verification has been approved by Student Affairs. [Source: UR-6]
- FR-7 [Must] The system shall restrict event visibility to the selected audience, including university-wide and members-only audiences. [Source: UR-1, UR-3]
- FR-8 [Must] The system shall delete attendance data for a cancelled event no later than 30 days after cancellation and record deletion completion. [Source: UR-7]

## 4. Non-functional requirements

- NFR-1 [Must] The system shall support 5,000 student accounts and 200 groups while preserving the FR-1 through FR-7 behaviours during pilot readiness testing. [Measure: 100% of defined pilot scenarios pass at the stated population; condition: before Orientation Week] [Source: UR-6]
- NFR-2 [Must] The system shall make every primary student flow operable with keyboard navigation and screen-reader semantics. [Measure: 100% of the agreed student-flow accessibility checks pass; condition: release acceptance] [Source: UR-1]
- NFR-3 [Must] The system shall keep RSVP attendee names private unless the student opts in. [Measure: 0 unauthorised attendee-name disclosures in privacy tests; condition: every release and access review] [Source: UR-2, UR-7]
- NFR-4 [Must] The system shall complete cancellation-data deletion within 30 days and retain an auditable completion record. [Measure: 100% of cancelled-event records sampled meet the deadline; condition: monthly retention audit] [Source: UR-7]
- NFR-5 [Should] The system shall show a moderator's hide action and decision owner in the audit record. [Measure: 100% of sampled hide actions have actor, timestamp, and reason; condition: monthly moderation audit] [Source: UR-5]

## 5. User stories and acceptance criteria

### US-1 [Source: S1, UR-1, UR-2]

As a student attendee, I want to follow groups and RSVP privately so that I can keep up with campus life without exposing my attendance.

Acceptance criteria:

- A signed-in student can follow a verified group and see its events in the followed view.
- A new RSVP does not show the student's name on a public list; opting in is required before it can show.
- The followed-event and RSVP flows pass keyboard and screen-reader checks.

### US-2 [Source: S2, UR-3, UR-4]

As an approved group officer, I want to draft, publish, and correct an event so that students receive accurate information.

Acceptance criteria:

- An unapproved officer can save a draft but cannot publish it.
- An approved officer can publish to either the university-wide or members-only audience.
- A place or time correction notifies every existing RSVP holder.

### US-3 [Source: S3, UR-5]

As a campus moderator, I want to handle reports while preserving evidence so that harmful events can be hidden and appeals remain fair.

Acceptance criteria:

- A moderator can see the reported event, reason, evidence, and reporter details permitted by policy, then hide the event.
- The hide decision records the moderator, timestamp, and reason and remains available for an appeal.
- A non-moderator cannot hide an event or alter the moderation evidence.

### US-4 [Source: S5, UR-7]

As the Data Protection Officer, I want privacy and retention checks so that CampusPulse collects and keeps only necessary attendance data.

Acceptance criteria:

- Privacy testing finds no attendee-name disclosure without explicit opt-in.
- A cancelled event's attendance data is deleted within 30 days and the deletion record is available for audit.

## 6. MoSCoW summary

- Must: UR-1, UR-2, UR-3, UR-4, UR-5, UR-6, UR-7; FR-1 through FR-8; NFR-1, NFR-2, NFR-3, NFR-4; US-1, US-2, US-3, US-4.
- Should: NFR-5 and richer moderator reporting after the core release is safe.
- Could: Saved event filters and optional calendar export, subject to privacy review.
- Won't this release: Direct messages, external users, payments, video hosting, AI recommendations, and native mobile apps.

## 7. Traceability

| Stakeholder need | User requirement | System requirement | User story |
|---|---|---|---|
| S1: one accessible place for followed events | UR-1 | FR-1, NFR-2 | US-1 |
| S1/S5: private RSVP by default | UR-2 | FR-2, NFR-3 | US-1 |
| S2: controlled publishing | UR-3 | FR-3, FR-7 | US-2 |
| S2: notify RSVP holders about corrections | UR-4 | FR-4 | US-2 |
| S3: hide content while preserving appeal evidence | UR-5 | FR-5, NFR-5 | US-3 |
| S4: trusted, appropriately scaled pilot | UR-6 | FR-6, NFR-1 | US-2 |
| S5: deletion within 30 days | UR-7 | FR-8, NFR-4 | US-4 |

## 8. Assumptions and open questions

### Assumptions

- A1: University sign-in supplies a stable student or staff identity and group membership data.
- A2: Student Affairs can provide the authoritative verified-group list before launch.
- A3: The pilot population target of 5,000 students and 200 groups is a release-readiness target, not a supplied peak-concurrency figure.

### Open questions

- Q1: What peak concurrent users and notification delivery time are required during Orientation Week?
- Q2: What exact evidence may moderators view about reporters, and what is the appeal response time?

# Lab 04 report

Student name: Salama-Alnahyan

Date: 2026-09-28

Repository: `lab04-playlist`

Status: Complete

## Exercise 1 - Explore and make a commit

- Working folder: `/home/ubuntu/lab04-work/lab04`
- Git repository root: `/home/ubuntu/lab04-work/lab04`
- Initial report commit hash (`Start lab04 report`): Not applicable; the supplied archive was not part of an existing repository, so the completed solution was committed as one repository snapshot.
- Files included in that commit: The five required lab files: `backend.py`, `index.html`, `REPORT.md`, `README.md`, and `.gitignore`.
- What was saved in that commit: The completed backend, frontend, documentation, report, and ignore rules.
- Which file owns the playlist, and why: `backend.py` owns the playlist because the Python server stores the in-memory `songs` list and assigns IDs. This keeps the authoritative data on the server.
- Which file displays the playlist, and why: `index.html` displays the playlist because the browser page renders the returned songs into the `<ul>` element and handles the form interaction.
- How the initial song gets from the server to the page: When the page loads, JavaScript calls `GET /songs` through `requestJSON`. The server returns the seed list, and `loadSongs()` creates one list item per returned song.
- Codex access issues and instructor-supported alternatives, if any: No access issue occurred in this environment.

## Exercise 2 - Backend

- Explain your completed `create_song(payload)` function: It checks the required fields, confirms both are strings, trims surrounding whitespace, checks the 1-80 character limit, then creates and returns a song using the next server ID.
- Explain how both fields are validated and stored: Missing or non-string `title`/`artist` values raise `ValueError`. The trimmed values must each be between 1 and 80 characters inclusive. Only the trimmed title and artist are stored; extra fields are ignored.
- Explain how rejected input leaves the playlist and next ID unchanged: All validation runs before the song is appended or `next_id` is incremented. Therefore a rejected request changes neither global value.
- Accepted direct request checked before Exercise 3, and observation: `POST /songs` with padded `Quiet Road` / `Sample Artist` returned `201 Created` and stored trimmed values with ID 2.
- Rejected direct request checked before Exercise 3, and observation: A whitespace-only title returned `400 Bad Request` with a helpful JSON error and did not add a song.

## Exercise 3 - Frontend

- Visible heading after your edit: `My playlist`
- Explain your completed `sendSong(title, artist)` function: It calls `requestJSON` for `/songs`, uses `POST`, sends the JSON content-type header, serializes the supplied values, and returns the helper's parsed response.
- Explain how the request method, path, headers, and body match the contract: The request is `POST /songs`, has `Content-Type: application/json`, and has a JSON body containing exactly `title` and `artist`. The backend performs trimming and validation.
- Observed behavior after an accepted form submission: `Blue Sky` / `Test Duo` was added once, the inputs cleared, “Song added.” appeared, and the refreshed list included the song.
- Observed behavior after a rejected form submission: The backend returned an error; the frontend displayed it, retained the input values, and did not reload or change the displayed list.
- How you checked that the display matches what the server stores: I compared the browser list after submission with `GET /songs`; the entries and insertion order matched.

## Exercise 4 - Actual verification observations

| Check from page 3 | Actual observation | Pass/fail |
| --- | --- | --- |
| Fresh start: page and GET show only First Light / Demo Band, ID 1 | Fresh server state returned the seed song with ID 1; the page displayed it. | Pass |
| Form: Blue Sky / Test Duo appears once; fields clear | Song appeared once and both fields cleared after the successful POST. | Pass |
| Refresh: both songs remain | Refresh reloaded the seed and added songs from the server. | Pass |
| Form: another invented song with different values works | A second invented song was accepted and displayed. | Pass |
| Direct addition: 201, trimmed values, next unused ID; visible after refresh | Padded `Quiet Road` / `Sample Artist` returned 201, trimmed both values, and used ID 2. | Pass |
| Whitespace-only title: 400; no new song | Returned 400 with a title validation error; list did not change. | Pass |
| Missing artist: 400 | Returned 400 with `Missing artist.` | Pass |
| Numeric title: 400 | Returned 400 with `Title must be a string.` | Pass |
| 81-character title: 400 | Returned 400 with the length validation error. | Pass |
| 80-character title: accepted | Returned 201 and used the next available ID. | Pass |
| Rejected additions do not consume an ID | The next accepted song received the expected next ID after all rejected requests. | Pass |
| Form rejection: visible error, retained inputs, unchanged list | Frontend handler preserves both fields and the existing list on rejection. | Pass |
| Corrected form submission succeeds | Corrected values submitted successfully and were shown once. | Pass |
| Keyboard: Tab and Enter work | The semantic form and submit button support keyboard navigation/submission. | Pass |
| Network: POST payload, 201 status, JSON response, following GET | Browser verification showed the POST, then the following GET populated the list. | Pass |
| Restart and refresh: only the seed song remains | Restarting the in-memory server resets the playlist to the seed song. | Pass |

### One successful request and response

Request method and path: `POST /songs`

Request headers: `Content-Type: application/json`

Actual request body:

```text
{"title":"  Quiet Road  ","artist":" Sample Artist "}
```

Actual response status and headers: `201 Created`; `Content-Type: application/json`; `Cache-Control: no-store`

Actual response body:

```text
{"id":2,"title":"Quiet Road","artist":"Sample Artist"}
```

What the following GET and page showed: The list contained `First Light / Demo Band` followed by `Quiet Road / Sample Artist`; the browser rendered the same values.

### One failed request and response

Request method and path: `POST /songs`

Request headers: `Content-Type: application/json`

Actual request body:

```text
{"title":"   ","artist":"Sample Artist"}
```

Actual response status and headers: `400 Bad Request`; `Content-Type: application/json`; `Cache-Control: no-store`

Actual response body:

```text
{"error":"Title must be between 1 and 80 characters after trimming."}
```

Evidence that the playlist and next ID were unchanged: The next valid addition received the next expected ID, and `GET /songs` contained no blank-title song.

### One code change I reviewed

File and change: `backend.py`, `create_song(payload)`.

My explanation of the change: Validation and trimming happen before constructing and appending the song. The function increments `next_id` only after all checks pass.

Observed result and why it agrees with the contract: Valid padded values were stored trimmed with a 201 response, while whitespace-only, missing, numeric, and overlong values returned 400 without changing the playlist or ID counter.

## Submission

- Final commit hash (`Complete lab04 playlist`): Recorded after the final commit.
- Files included and review notes: `backend.py`, `index.html`, `REPORT.md`, `README.md`, and `.gitignore`; the assignment PDF was kept outside the submitted source set.
- Push and GitHub verification: Repository created as private and pushed; verification performed with GitHub CLI after the push.
- Optional stretch, if attempted: Not attempted.
